Open N++

Go To Language > Define your Language > Import > Arduino_Language_0.2.0.xml

Copy APIs to "your n++ path"/Notepad++/plugins/ 

Go to Settings > Preferences > Auto-Completion and enable funtion completion & function parameters hint

HAVE FUN!